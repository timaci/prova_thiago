import 'package:flutter/material.dart';

import 'generations.dart'; // Importe o modelo Generation
import 'teladetalhegeracoes.dart'; // Importe a tela de detalhes da geração

class TelaDeGeracoes extends StatelessWidget {
  final List<Generation> generations; // A lista de gerações

  TelaDeGeracoes({
    required this.generations,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gerações de Pokémon'),
      ),
      body: ListView.builder(
        itemCount: generations.length,
        itemBuilder: (context, index) {
          final generation = generations[index];
          return ListTile(
            title: Text(generation.title),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => TelaDetalhesGeracao(geracao: generation),
              ));
            },
          );
        },
      ),
    );
  }
}
