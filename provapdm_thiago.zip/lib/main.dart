import 'package:flutter/material.dart';
import 'package:provapdm/tela_de_geracoes.dart'; // Importe a tela de gerações
import 'generations.dart'; // Importe o arquivo com a lista de gerações

void main() {
  runApp(MeuApp());
}

class MeuApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pokedex',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TelaDeGeracoes(
        generations: generations, // Use a lista de gerações do arquivo generations.dart
      ),
    );
  }
}
